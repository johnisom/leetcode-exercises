import React from "react";
import CommentList from "./CommentList";
import CommentForm from "./CommentForm";
import commentsData from "../lib/comments";

/*

Comment App - React must return one element
  Comment list
    - Parent Comment
        - Comment
          - Reply...
  Add comment
    - Form

- Generally better to work top down with React
*/

class CommentApp extends React.Component {
  state = {
    comments: [],
  };

  componentDidMount() {
    this.setState({ comments: commentsData });
  }

  render() {
    return (
      <div>
        <CommentList comments={this.state.comments} />
        <CommentForm />
      </div>
    );
  }
}

export default CommentApp;
