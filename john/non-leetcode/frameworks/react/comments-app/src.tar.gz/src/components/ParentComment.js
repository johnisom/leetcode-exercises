import React from "react";
import Comment from "./Comment";

const ParentComment = ({ comment, onShowMoreReplies }) => {
  const handleShowMoreReplies = function handleShowMoreReplies(event) {
    event.preventDefault();
    onShowMoreReplies(comment.id);
  };

  return (
    <div className="parent-comment">
      <Comment {...comment} />
      <div className="replies">
        {comment.replies.map((reply) => {
          return <Comment key={reply.id} {...reply} />;
        })}

        {comment.replies_count === comment.replies.length ? null : (
          <a href="#" className="show_more" onClick={handleShowMoreReplies}>
            Show More Replies ({comment.replies_count - 1})
          </a>
        )}
      </div>
    </div>
  );
};

export default ParentComment;
