import React from "react";
import ParentComment from "./ParentComment";

const CommentList = ({ comments, onShowMoreReplies }) => (
  <div className="comments">
    <h2>Comments (2)</h2>
    {comments.map((comment) => (
      <ParentComment
        key={comment.id}
        comment={comment}
        onShowMoreReplies={onShowMoreReplies}
      />
    ))}
  </div>
);

export default CommentList;
